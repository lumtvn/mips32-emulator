var searchData=
[
  ['maxbreakpoints',['MAXBREAKPOINTS',['../headers_8h.html#a87078043e6250a405d31fb62b3a82177',1,'headers.h']]],
  ['maxfilesize',['MAXFILESIZE',['../headers_8h.html#ad683dabfc817a52d9fc31d7b698d654a',1,'headers.h']]],
  ['maxsize',['MAXSIZE',['../headers_8h.html#a2a37b4217917105aac7557862ccc19c3',1,'headers.h']]]
];
