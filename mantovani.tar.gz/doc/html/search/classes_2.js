var searchData=
[
  ['nlist',['nlist',['../structnlist.html',1,'']]]
];
