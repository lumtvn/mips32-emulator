var searchData=
[
  ['s3_5fopcode_5fbits',['S3_OPCODE_BITS',['../disassembler_8c.html#a2b954f97aab789f3a3c156e43fb1745e',1,'disassembler.c']]],
  ['s_5farg1',['s_arg1',['../structmipsstr.html#add8959dcc4d0ec1c7408315d09b11bf0',1,'mipsstr']]],
  ['s_5farg2',['s_arg2',['../structmipsstr.html#a744f61bf3b3b9a53e684ba8dfa718012',1,'mipsstr']]],
  ['s_5farg3',['s_arg3',['../structmipsstr.html#ac74368f02c1d9ed9465504f28ced8d41',1,'mipsstr']]],
  ['s_5farg4',['s_arg4',['../structmipsstr.html#a25dc465bb99367150e998a26d835d5b8',1,'mipsstr']]],
  ['s_5fopcode_5fbits',['S_OPCODE_BITS',['../disassembler_8c.html#abbdeae9647ed88bbc88d433fb1968684',1,'disassembler.c']]],
  ['send_5foperation',['send_operation',['../disassembler_8c.html#a38afa642087e4e3b77753c0104d40206',1,'send_operation(struct mipsstr *mips, action act):&#160;disassembler.c'],['../disassembler_8h.html#ad29ae35a0f288dd6f488a7f3a1a2c5f7',1,'send_operation(struct mipsstr *mips, action ac):&#160;disassembler.c']]],
  ['six_5fmsb',['SIX_MSB',['../disassembler_8c.html#a3fee98731e8a99abc17b926890a6fe3d',1,'disassembler.c']]],
  ['start_5fand_5fload',['start_and_load',['../elfmanager_8c.html#a7549abf21f71069282d0e0f2f6706471',1,'start_and_load(struct elfstr *elfdata, char *filename, uint start_mem):&#160;elfmanager.c'],['../elfmanager_8h.html#a7549abf21f71069282d0e0f2f6706471',1,'start_and_load(struct elfstr *elfdata, char *filename, uint start_mem):&#160;elfmanager.c']]],
  ['start_5fmem',['start_mem',['../elfmanager_8h.html#ae8f0fbb0289e3e089258e9e554b32d42',1,'start_mem(struct elfstr *elfdata):&#160;elfmanager.h'],['../elfmanager_8c.html#ae3af29a4fc148ddd9b7b7b8342c53c01',1,'START_MEM():&#160;elfmanager.c']]],
  ['strip',['strip',['../environment_8c.html#a76299b86e144434260dcab80323ec9da',1,'strip(char *s):&#160;environment.c'],['../environment_8h.html#a76299b86e144434260dcab80323ec9da',1,'strip(char *s):&#160;environment.c']]],
  ['symtab',['symtab',['../structelfstr.html#a1534fd3623fdb1954bf49ef9f5f3545d',1,'elfstr']]]
];
