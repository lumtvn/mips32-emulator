var searchData=
[
  ['defn',['defn',['../structnlist.html#a6484d2c28591e89bcffbda34d3e1bde2',1,'nlist']]],
  ['disasm_5foutput',['disasm_output',['../structmipsstr.html#a5d597d99653d28db30a20d300a9835c9',1,'mipsstr']]]
];
