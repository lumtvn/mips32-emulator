var searchData=
[
  ['cleandata',['cleandata',['../elfmanager_8c.html#a164f3236800c4293bed729219a65c886',1,'elfmanager.c']]]
];
