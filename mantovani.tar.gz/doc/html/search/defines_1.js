var searchData=
[
  ['data_5fsection_5fstr',['DATA_SECTION_STR',['../elfmanager_8h.html#a4f986ae3363e6dbf75efe82d47202c86',1,'elfmanager.h']]]
];
