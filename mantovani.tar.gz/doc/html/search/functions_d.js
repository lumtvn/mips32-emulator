var searchData=
[
  ['send_5foperation',['send_operation',['../disassembler_8c.html#a38afa642087e4e3b77753c0104d40206',1,'send_operation(struct mipsstr *mips, action act):&#160;disassembler.c'],['../disassembler_8h.html#ad29ae35a0f288dd6f488a7f3a1a2c5f7',1,'send_operation(struct mipsstr *mips, action ac):&#160;disassembler.c']]],
  ['start_5fand_5fload',['start_and_load',['../elfmanager_8c.html#a7549abf21f71069282d0e0f2f6706471',1,'start_and_load(struct elfstr *elfdata, char *filename, uint start_mem):&#160;elfmanager.c'],['../elfmanager_8h.html#a7549abf21f71069282d0e0f2f6706471',1,'start_and_load(struct elfstr *elfdata, char *filename, uint start_mem):&#160;elfmanager.c']]],
  ['start_5fmem',['start_mem',['../elfmanager_8h.html#ae8f0fbb0289e3e089258e9e554b32d42',1,'elfmanager.h']]],
  ['strip',['strip',['../environment_8c.html#a76299b86e144434260dcab80323ec9da',1,'strip(char *s):&#160;environment.c'],['../environment_8h.html#a76299b86e144434260dcab80323ec9da',1,'strip(char *s):&#160;environment.c']]]
];
