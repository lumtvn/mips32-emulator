var searchData=
[
  ['i_5ftype',['I_TYPE',['../disassembler_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba8445f1117355d4bc7f575eb525d96183',1,'disassembler.h']]],
  ['initregisters',['initregisters',['../main_8c.html#a7cfab0b99fe754526abbe8c401c123ac',1,'main.c']]],
  ['inmediate',['inmediate',['../structmipsstr.html#a28a6aa07a3d1cfaa4c5b96812b268057',1,'mipsstr']]],
  ['install',['install',['../lookup_8c.html#a94f41788b6c7255236e7a28b1ea71580',1,'install(char *name, char *defn):&#160;lookup.c'],['../lookup_8h.html#a94f41788b6c7255236e7a28b1ea71580',1,'install(char *name, char *defn):&#160;lookup.c']]],
  ['instr_5foutput',['instr_output',['../structmipsstr.html#a017eed0b4aedbc07607395e26a4ae856',1,'mipsstr']]],
  ['instr_5ftype',['instr_type',['../disassembler_8h.html#addd9b31da169bdf5411b611229d8dfe9',1,'disassembler.h']]],
  ['is_5fin_5fsegment',['is_in_segment',['../elfmanager_8c.html#a79d2d174df8b264d78386a01f9441b17',1,'is_in_segment(segment *seg, vaddr32 v, uint size):&#160;elfmanager.c'],['../elfmanager_8h.html#a79d2d174df8b264d78386a01f9441b17',1,'is_in_segment(segment *seg, vaddr32 v, uint size):&#160;elfmanager.c']]],
  ['is_5fin_5fsymbols',['is_in_symbols',['../elfmanager_8c.html#ab5931f0255d72df1fd95c4515c89ea16',1,'is_in_symbols(char *name, stab symtab):&#160;elfmanager.c'],['../elfmanager_8h.html#ab5931f0255d72df1fd95c4515c89ea16',1,'is_in_symbols(char *name, stab symtab):&#160;elfmanager.c']]]
];
