var searchData=
[
  ['rg_5fopcode_5fbits',['RG_OPCODE_BITS',['../disassembler_8c.html#a820d50e845b68d3b489cb864395d93a2',1,'disassembler.c']]],
  ['rodata_5fsection_5fstr',['RODATA_SECTION_STR',['../elfmanager_8h.html#a162ca0ad9d277c0e1951bb5e1ba09525',1,'elfmanager.h']]]
];
