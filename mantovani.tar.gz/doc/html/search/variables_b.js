var searchData=
[
  ['operation',['operation',['../structmipsstr.html#acb7d490f8d903ed61f6b48ff2b41e8e4',1,'mipsstr']]],
  ['opnum',['opnum',['../structmipsstr.html#aa4f6fc1d8f9d3828effa2e4136efe9a4',1,'mipsstr']]]
];
