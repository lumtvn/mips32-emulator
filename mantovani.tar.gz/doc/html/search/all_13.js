var searchData=
[
  ['wdata',['wdata',['../structmipsstr.html#ad46e349f5294cbfd00c975a522cf12eb',1,'mipsstr']]],
  ['which_5foperation_5fnumber',['which_operation_number',['../disassembler_8c.html#a969256873f894c820282e5d272bd87ff',1,'which_operation_number(struct mipsstr *mips):&#160;disassembler.c'],['../disassembler_8h.html#a969256873f894c820282e5d272bd87ff',1,'which_operation_number(struct mipsstr *mips):&#160;disassembler.c']]],
  ['which_5fseg',['which_seg',['../elfmanager_8c.html#a5b877842bf327e8dfe2340f1acf23be2',1,'which_seg(mem m, vaddr32 v, uint size):&#160;elfmanager.c'],['../elfmanager_8h.html#a5b877842bf327e8dfe2340f1acf23be2',1,'which_seg(mem m, vaddr32 v, uint size):&#160;elfmanager.c']]]
];
