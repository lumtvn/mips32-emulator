var searchData=
[
  ['destroy_5fmem',['destroy_mem',['../elfmanager_8c.html#a637be9befaf3faa5e6e8d3c27a643775',1,'destroy_mem(struct elfstr *elfdata):&#160;elfmanager.c'],['../elfmanager_8h.html#a637be9befaf3faa5e6e8d3c27a643775',1,'destroy_mem(struct elfstr *elfdata):&#160;elfmanager.c']]],
  ['disasm_5finstr',['disasm_instr',['../disassembler_8c.html#a57ca7b91cf55211a3039ac4d3740b4be',1,'disasm_instr(struct mipsstr *mips, vaddr32 addr, action act):&#160;disassembler.c'],['../disassembler_8h.html#affe7f12531260ab1023d76e5cc386a7d',1,'disasm_instr(struct mipsstr *mips, vaddr32 addr, action ac):&#160;disassembler.c']]]
];
