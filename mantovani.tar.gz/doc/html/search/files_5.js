var searchData=
[
  ['operations_2ec',['operations.c',['../operations_8c.html',1,'']]],
  ['operations_2eh',['operations.h',['../operations_8h.html',1,'']]]
];
