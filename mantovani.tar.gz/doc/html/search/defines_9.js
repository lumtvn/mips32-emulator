var searchData=
[
  ['text_5fsection_5fstr',['TEXT_SECTION_STR',['../elfmanager_8h.html#a9d40fbd402772d56fffd9022ee177772',1,'elfmanager.h']]],
  ['true',['true',['../headers_8h.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7',1,'headers.h']]]
];
