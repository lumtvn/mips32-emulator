var searchData=
[
  ['undef',['undef',['../lookup_8c.html#ab02531b2d65608b19df1c85148f32d15',1,'undef(char *name):&#160;lookup.c'],['../lookup_8h.html#ab02531b2d65608b19df1c85148f32d15',1,'undef(char *name):&#160;lookup.c']]]
];
