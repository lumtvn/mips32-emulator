var searchData=
[
  ['r_5ftype',['R_TYPE',['../disassembler_8h.html#a06fc87d81c62e9abb8790b6e5713c55bad2870a38b63e6595b0c26cd5d3e5131a',1,'disassembler.h']]],
  ['reg',['reg',['../headers_8h.html#aebd23a20a0f68532d8a091fb411d4d02',1,'headers.h']]],
  ['regs',['regs',['../structmipsstr.html#ab9af1a7f2757b11905240c33112496b8',1,'mipsstr']]],
  ['relocate_5fsegment',['relocate_segment',['../elfmanager_8c.html#a35e7134d5ba055f7caed19ac7263113a',1,'relocate_segment(struct mipsstr *mips, char *name):&#160;elfmanager.c'],['../elfmanager_8h.html#a35e7134d5ba055f7caed19ac7263113a',1,'relocate_segment(struct mipsstr *mips, char *name):&#160;elfmanager.c']]],
  ['report',['report',['../structmipsstr.html#af8ae873dc0a6bcadf6bf4500b857288a',1,'mipsstr::report()'],['../structelfstr.html#af8ae873dc0a6bcadf6bf4500b857288a',1,'elfstr::report()'],['../errors_8c.html#a21ee71274a5d6aa9fd3063a810e97926',1,'report(int r):&#160;errors.c'],['../errors_8h.html#a21ee71274a5d6aa9fd3063a810e97926',1,'report(int r):&#160;errors.c']]],
  ['restart',['restart',['../environment_8c.html#abb5d9b8ff80a6ab008402824b018f304',1,'restart(struct mipsstr *mips):&#160;environment.c'],['../environment_8h.html#ae81bedab34af581d0f0f744a58b99db6',1,'restart(struct mipsstr *env):&#160;environment.c']]],
  ['rg_5fopcode_5fbits',['RG_OPCODE_BITS',['../disassembler_8c.html#a820d50e845b68d3b489cb864395d93a2',1,'disassembler.c']]],
  ['rodata_5fsection_5fstr',['RODATA_SECTION_STR',['../elfmanager_8h.html#a162ca0ad9d277c0e1951bb5e1ba09525',1,'elfmanager.h']]],
  ['run',['run',['../disassembler_8h.html#ad243a63026110a03145303c94036211d',1,'disassembler.h']]],
  ['runenv',['runenv',['../environment_8c.html#a3aff06844c3f8bd1546a7daabfaa48b4',1,'runenv(struct mipsstr *mips):&#160;environment.c'],['../environment_8h.html#a50b7a05356ab5a64a24f5cdec2971587',1,'runenv(struct mipsstr *env):&#160;environment.c']]]
];
