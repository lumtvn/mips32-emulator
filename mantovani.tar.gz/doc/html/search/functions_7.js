var searchData=
[
  ['index_5fin_5fsymbols',['index_in_symbols',['../elfmanager_8c.html#ab2c58a95e267c32915ce8cc3c64347cc',1,'index_in_symbols(char *name, stab symtab):&#160;elfmanager.c'],['../elfmanager_8h.html#ab2c58a95e267c32915ce8cc3c64347cc',1,'index_in_symbols(char *name, stab symtab):&#160;elfmanager.c']]],
  ['initregisters',['initregisters',['../main_8c.html#a7cfab0b99fe754526abbe8c401c123ac',1,'main.c']]],
  ['install',['install',['../lookup_8c.html#a94f41788b6c7255236e7a28b1ea71580',1,'install(char *name, char *defn):&#160;lookup.c'],['../lookup_8h.html#a94f41788b6c7255236e7a28b1ea71580',1,'install(char *name, char *defn):&#160;lookup.c']]],
  ['is_5fin_5fsegment',['is_in_segment',['../elfmanager_8c.html#a79d2d174df8b264d78386a01f9441b17',1,'is_in_segment(segment *seg, vaddr32 v, uint size):&#160;elfmanager.c'],['../elfmanager_8h.html#a79d2d174df8b264d78386a01f9441b17',1,'is_in_segment(segment *seg, vaddr32 v, uint size):&#160;elfmanager.c']]],
  ['is_5fin_5fsymbols',['is_in_symbols',['../elfmanager_8c.html#ab5931f0255d72df1fd95c4515c89ea16',1,'is_in_symbols(char *name, stab symtab):&#160;elfmanager.c'],['../elfmanager_8h.html#ab5931f0255d72df1fd95c4515c89ea16',1,'is_in_symbols(char *name, stab symtab):&#160;elfmanager.c']]]
];
