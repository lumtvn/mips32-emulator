#!/usr/bin/bash
chmod 755 ../bin/emul-mips
cp ../bin/emul-mips /usr/local/bin