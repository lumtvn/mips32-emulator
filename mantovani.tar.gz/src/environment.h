int runenv(struct mipsstr *env);
void restart(struct mipsstr *env);
struct mipsstr *parseentry(struct mipsstr *env);
struct mipsstr *analize(struct mipsstr *env);
void strip(char *s);

