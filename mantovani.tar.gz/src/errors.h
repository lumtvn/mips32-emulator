//error handling
#define ERRNUM 3
void op_report(int r);
void report(int r);