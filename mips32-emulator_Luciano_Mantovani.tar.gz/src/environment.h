void runenv(struct ptype *env);
void restart(struct ptype *env);
struct ptype *parseentry(struct ptype *env);
struct ptype *analize(struct ptype *env);
void strip(char *s);

