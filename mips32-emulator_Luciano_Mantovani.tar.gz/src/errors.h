//error handling
#define ERRNUM 3
void report(int r);