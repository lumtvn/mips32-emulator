var searchData=
[
  ['tag',['tag',['../structptype.html#a7bb5e40c10df6a41df64bda1f4bb3e26',1,'ptype']]]
];
