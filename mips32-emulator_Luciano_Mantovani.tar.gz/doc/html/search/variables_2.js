var searchData=
[
  ['defn',['defn',['../structnlist.html#a6484d2c28591e89bcffbda34d3e1bde2',1,'nlist']]]
];
