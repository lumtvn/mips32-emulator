var searchData=
[
  ['reader_2ec',['reader.c',['../reader_8c.html',1,'']]],
  ['reader_2eh',['reader.h',['../reader_8h.html',1,'']]]
];
