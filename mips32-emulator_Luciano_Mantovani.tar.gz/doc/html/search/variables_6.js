var searchData=
[
  ['memrealpoint',['memrealpoint',['../structptype.html#a0e240a34245d5734a5ab1133bd37182a',1,'ptype']]],
  ['memrealpointbase',['memrealpointbase',['../structptype.html#ae48d8e85e5f5b594209aeba44b50e810',1,'ptype']]],
  ['memsize',['memsize',['../structptype.html#aedc8878c46b29532ca5d23cd9bca22ad',1,'ptype']]]
];
