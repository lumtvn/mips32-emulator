var searchData=
[
  ['maxfilesize',['MAXFILESIZE',['../headers_8h.html#ad683dabfc817a52d9fc31d7b698d654a',1,'headers.h']]],
  ['maxsize',['MAXSIZE',['../headers_8h.html#a2a37b4217917105aac7557862ccc19c3',1,'headers.h']]]
];
