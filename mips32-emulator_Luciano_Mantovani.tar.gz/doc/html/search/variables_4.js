var searchData=
[
  ['filename',['filename',['../structptype.html#aeac90097f29f7529968697163cea5c18',1,'ptype']]],
  ['filesize',['filesize',['../structptype.html#ab098377a95401616fe523fc66ce6e212',1,'ptype']]]
];
