var searchData=
[
  ['destroymemory',['destroymemory',['../memorymanagement_8c.html#af5aaff9896bee3ef2604ca4c4d38dd8f',1,'destroymemory(struct ptype *mips):&#160;memorymanagement.c'],['../memorymanagement_8h.html#af5aaff9896bee3ef2604ca4c4d38dd8f',1,'destroymemory(struct ptype *mips):&#160;memorymanagement.c']]],
  ['displaymemory',['displaymemory',['../memorymanagement_8c.html#ad4daae96394e22511381b56c2384867c',1,'displaymemory(struct ptype *mips):&#160;memorymanagement.c'],['../memorymanagement_8h.html#ae99d5a529c7bcbdbe6f5432bfa4ec957',1,'displaymemory(struct ptype *mem):&#160;memorymanagement.c']]]
];
