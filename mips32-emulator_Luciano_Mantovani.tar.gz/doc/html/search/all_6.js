var searchData=
[
  ['get_5fnormalopcode',['get_normalopcode',['../disassembler_8h.html#a0399ebc7ab120b671bea3863585660bb',1,'disassembler.h']]],
  ['get_5fnsegments',['get_nsegments',['../elfmanager_8c.html#a63f546e4e96db828fc78e883767c3c24',1,'get_nsegments(stab symtab, char *section_names[], int nb_sections):&#160;elfmanager.c'],['../elfmanager_8h.html#a63f546e4e96db828fc78e883767c3c24',1,'get_nsegments(stab symtab, char *section_names[], int nb_sections):&#160;elfmanager.c']]],
  ['get_5fregimmopcode',['get_regimmopcode',['../disassembler_8h.html#aedf828d6c13f50ba4c3e5eb267e93205',1,'disassembler.h']]],
  ['get_5fspecial3opcode',['get_special3opcode',['../disassembler_8h.html#a1c5b188c9bd5b68530560182863fcaca',1,'disassembler.h']]],
  ['get_5fspecialopcode',['get_specialopcode',['../disassembler_8h.html#ad4fa7759411c285ee19b791d5591988e',1,'disassembler.h']]],
  ['getopcode',['getopcode',['../disassembler_8c.html#a94d274d1eb5af41c6c75d19c3aeb808a',1,'getopcode(struct ptype *mips, mword word):&#160;disassembler.c'],['../disassembler_8h.html#a4fdf0659e3e85069b05f6e8139aab13a',1,'getopcode(struct ptype *mips, mword a):&#160;disassembler.c']]]
];
