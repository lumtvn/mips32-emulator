var searchData=
[
  ['label',['label',['../structptype.html#acf60de4c64d60c1b9449c056bc6bfcf7',1,'ptype']]]
];
