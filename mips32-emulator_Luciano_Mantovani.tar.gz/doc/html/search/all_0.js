var searchData=
[
  ['analize',['analize',['../environment_8c.html#abf6f7ac059bdc924fd15ab429c6a3705',1,'analize(struct ptype *mips):&#160;environment.c'],['../environment_8h.html#a862eb51421e0e385b08373734f9a1f5e',1,'analize(struct ptype *env):&#160;environment.c']]],
  ['argenv',['argenv',['../structptype.html#a33ff9c19364c52cc4ff54db3a01bf135',1,'ptype']]],
  ['argline',['argline',['../structptype.html#a0d565ad5f0354bb96aaab4d9721ffb03',1,'ptype']]]
];
