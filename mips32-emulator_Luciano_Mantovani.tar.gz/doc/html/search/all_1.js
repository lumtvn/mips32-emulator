var searchData=
[
  ['bool',['bool',['../headers_8h.html#a1062901a7428fdd9c7f180f5e01ea056',1,'headers.h']]],
  ['bss_5fsection_5fstr',['BSS_SECTION_STR',['../elfmanager_8h.html#a92b8f6a231df9a891ce480bba1726696',1,'elfmanager.h']]]
];
