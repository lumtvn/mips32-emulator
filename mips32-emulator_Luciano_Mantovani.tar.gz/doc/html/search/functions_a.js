var searchData=
[
  ['parseentry',['parseentry',['../environment_8c.html#abe56c7942fc708683388745a9fa6fee8',1,'parseentry(struct ptype *mips):&#160;environment.c'],['../environment_8h.html#ab0b28bc422d4029eb6a1bcd29a8bc6bb',1,'parseentry(struct ptype *env):&#160;environment.c']]]
];
