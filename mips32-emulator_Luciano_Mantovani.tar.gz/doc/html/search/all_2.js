var searchData=
[
  ['command',['command',['../structptype.html#ade9cba72805fe52685a1deea307a8e82',1,'ptype']]],
  ['creatememory',['creatememory',['../memorymanagement_8c.html#aeac4b86096cffcc102d3ee6c91c67765',1,'creatememory(struct ptype *mips, int size):&#160;memorymanagement.c'],['../memorymanagement_8h.html#a3c6cf2e7e24b754f8d06d5eb5eff1917',1,'creatememory(struct ptype *mem, int size):&#160;memorymanagement.c']]],
  ['createsegment',['createsegment',['../memorymanagement_8c.html#a897f629b5ff78c022e0e9379418b3384',1,'createsegment(struct ptype *mips, char *name, int size, int permissions, int start):&#160;memorymanagement.c'],['../memorymanagement_8h.html#a897f629b5ff78c022e0e9379418b3384',1,'createsegment(struct ptype *mips, char *name, int size, int permissions, int start):&#160;memorymanagement.c']]]
];
