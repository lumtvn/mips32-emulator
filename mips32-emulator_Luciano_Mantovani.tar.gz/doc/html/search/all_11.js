var searchData=
[
  ['writebyte',['writebyte',['../memorymanagement_8c.html#aeddb4414ba32f9f702a0ebce7911f311',1,'writebyte(struct ptype *mips, mbyte bdata, int simpoint):&#160;memorymanagement.c'],['../memorymanagement_8h.html#a68f492c5ea309f9aef8d8f0d04b4a55c',1,'writebyte(struct ptype *mem, mbyte bdata, int simpoint):&#160;memorymanagement.c']]],
  ['writehalfword',['writehalfword',['../memorymanagement_8c.html#a54e7d0d4a184c94e7487c6cdfb804053',1,'writehalfword(struct ptype *mips, mhalfword hwdata, int simpoint):&#160;memorymanagement.c'],['../memorymanagement_8h.html#a023bf1fde93969aa804ae8a44b57fdcd',1,'writehalfword(struct ptype *mem, mhalfword hwdata, int simpoint):&#160;memorymanagement.c']]],
  ['writeword',['writeword',['../memorymanagement_8c.html#a8a83a83ac160e30788c793b808cff5d2',1,'writeword(struct ptype *mips, mword wdata, int simpoint):&#160;memorymanagement.c'],['../memorymanagement_8h.html#a2a9a2e017cc79e37fd56a648ba0a36b8',1,'writeword(struct ptype *mem, mword bdata, int simpoint):&#160;memorymanagement.c']]]
];
