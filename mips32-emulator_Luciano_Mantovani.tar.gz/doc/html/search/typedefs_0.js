var searchData=
[
  ['bool',['bool',['../headers_8h.html#a1062901a7428fdd9c7f180f5e01ea056',1,'headers.h']]]
];
