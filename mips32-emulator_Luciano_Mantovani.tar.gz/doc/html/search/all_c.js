var searchData=
[
  ['operation',['operation',['../structptype.html#acb7d490f8d903ed61f6b48ff2b41e8e4',1,'ptype']]]
];
