var searchData=
[
  ['main',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.c']]],
  ['my_5finit_5fmem',['my_init_mem',['../elfmanager_8c.html#aeaf0fcb2c48ff3caae31b1460856dafd',1,'my_init_mem(struct ptype *mips, char *filename):&#160;elfmanager.c'],['../elfmanager_8h.html#aeaf0fcb2c48ff3caae31b1460856dafd',1,'my_init_mem(struct ptype *mips, char *filename):&#160;elfmanager.c']]]
];
