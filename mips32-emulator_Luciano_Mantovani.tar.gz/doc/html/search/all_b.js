var searchData=
[
  ['n_5fargenv',['n_argenv',['../structptype.html#a1098a1ee1a85bb05e0e55b49df030979',1,'ptype']]],
  ['name',['name',['../structnlist.html#a5ac083a645d964373f022d03df4849c8',1,'nlist']]],
  ['nb_5fsections',['NB_SECTIONS',['../elfmanager_8h.html#ac99929abfd0905e9c896aa3e98834aad',1,'elfmanager.h']]],
  ['next',['next',['../structnlist.html#ac81a332322794f80995e550bb3b7165b',1,'nlist']]],
  ['nlist',['nlist',['../structnlist.html',1,'']]],
  ['nsegs',['nsegs',['../structptype.html#a7f5e7921f604a6a00c34a4cccca73a08',1,'ptype']]]
];
