var searchData=
[
  ['analize',['analize',['../environment_8c.html#abf6f7ac059bdc924fd15ab429c6a3705',1,'analize(struct ptype *mips):&#160;environment.c'],['../environment_8h.html#a862eb51421e0e385b08373734f9a1f5e',1,'analize(struct ptype *env):&#160;environment.c']]]
];
