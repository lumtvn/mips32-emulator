var searchData=
[
  ['initregisters',['initregisters',['../main_8c.html#af9a6298ae73a9d49db082d26d1768f11',1,'main.c']]],
  ['install',['install',['../lookup_8c.html#a94f41788b6c7255236e7a28b1ea71580',1,'install(char *name, char *defn):&#160;lookup.c'],['../lookup_8h.html#a94f41788b6c7255236e7a28b1ea71580',1,'install(char *name, char *defn):&#160;lookup.c']]],
  ['is_5fin_5fsymbols',['is_in_symbols',['../elfmanager_8c.html#ab5931f0255d72df1fd95c4515c89ea16',1,'is_in_symbols(char *name, stab symtab):&#160;elfmanager.c'],['../elfmanager_8h.html#ab5931f0255d72df1fd95c4515c89ea16',1,'is_in_symbols(char *name, stab symtab):&#160;elfmanager.c']]]
];
