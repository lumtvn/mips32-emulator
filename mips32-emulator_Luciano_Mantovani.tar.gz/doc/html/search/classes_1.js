var searchData=
[
  ['ptype',['ptype',['../structptype.html',1,'']]]
];
