var searchData=
[
  ['readbyte',['readbyte',['../memorymanagement_8c.html#a08a84af40832349127e7467b3e46a527',1,'readbyte(struct ptype *mips, int simpoint):&#160;memorymanagement.c'],['../memorymanagement_8h.html#a14b78240e6715543f38c2a80a9badff2',1,'readbyte(struct ptype *mem, int simpoint):&#160;memorymanagement.c']]],
  ['readhalfword',['readhalfword',['../memorymanagement_8c.html#a8ccb1846c4d20cee79fe2bb3dbfdace9',1,'readhalfword(struct ptype *mips, int simpoint):&#160;memorymanagement.c'],['../memorymanagement_8h.html#a0bb9d891ad68a04e01985203eb047df4',1,'readhalfword(struct ptype *mem, int simpoint):&#160;memorymanagement.c']]],
  ['readword',['readword',['../memorymanagement_8c.html#a64aa24d9d65246e2fcd07763f586c82f',1,'readword(struct ptype *mips, int simpoint):&#160;memorymanagement.c'],['../memorymanagement_8h.html#a43f719968ee135dba6d01195f93de231',1,'readword(struct ptype *mem, int simpoint):&#160;memorymanagement.c']]],
  ['report',['report',['../errors_8c.html#a21ee71274a5d6aa9fd3063a810e97926',1,'report(int r):&#160;errors.c'],['../errors_8h.html#a21ee71274a5d6aa9fd3063a810e97926',1,'report(int r):&#160;errors.c']]],
  ['restart',['restart',['../environment_8c.html#a2814459b97fdfb4bb98005ae434c90ec',1,'restart(struct ptype *mips):&#160;environment.c'],['../environment_8h.html#a7f8c6daa507bbe98cadd9fa3059d72d0',1,'restart(struct ptype *env):&#160;environment.c']]],
  ['runenv',['runenv',['../environment_8c.html#a2b9126aae72ec084d893aef42b74ba6c',1,'runenv(struct ptype *mips):&#160;environment.c'],['../environment_8h.html#ad87acf8d67cccdc9bfffef60ccf5c8a6',1,'runenv(struct ptype *env):&#160;environment.c']]]
];
