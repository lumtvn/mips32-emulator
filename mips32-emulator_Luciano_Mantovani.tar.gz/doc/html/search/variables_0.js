var searchData=
[
  ['argenv',['argenv',['../structptype.html#a33ff9c19364c52cc4ff54db3a01bf135',1,'ptype']]],
  ['argline',['argline',['../structptype.html#a0d565ad5f0354bb96aaab4d9721ffb03',1,'ptype']]]
];
