var searchData=
[
  ['strip',['strip',['../environment_8c.html#a76299b86e144434260dcab80323ec9da',1,'strip(char *s):&#160;environment.c'],['../environment_8h.html#a76299b86e144434260dcab80323ec9da',1,'strip(char *s):&#160;environment.c']]]
];
