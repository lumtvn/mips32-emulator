var searchData=
[
  ['nb_5fsections',['NB_SECTIONS',['../elfmanager_8h.html#ac99929abfd0905e9c896aa3e98834aad',1,'elfmanager.h']]]
];
