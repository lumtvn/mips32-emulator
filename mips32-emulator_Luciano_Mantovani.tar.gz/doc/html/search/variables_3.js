var searchData=
[
  ['entry',['entry',['../structptype.html#a1072c713adb03fb67b07874dc9585a77',1,'ptype']]]
];
