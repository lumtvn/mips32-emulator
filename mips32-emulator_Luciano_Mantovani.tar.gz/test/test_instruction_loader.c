#include "../src/headers.h"
#include "../src/instruction_loader.h"
#include "minunit.h"

 int tests_run = 0; 
 int res;

 static char * test_diff() 
{

}
 
 
 static char * all_tests() {
    mu_run_test(test_diff);
     return 0;

 }
 
 int main(int argc, char **argv) {

    

     else {
         // printf("INSTRUCTION LOADER TEST PASSED\n");
     }
     // printf("Tests run: %d\n", tests_run);
 
     return result != 0;
 }
